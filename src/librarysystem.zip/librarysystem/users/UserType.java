package librarysystem.users;

public enum UserType {
	
	ADMINISTRATOR(),
	CLERK(),
	FACULTY(),
	INSTRUCTOR(),
	LIBRARIAN(),
	TEACHING_ASSISTANT(),
	STUDENT();
}
